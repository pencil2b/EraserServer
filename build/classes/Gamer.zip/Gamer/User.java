package Gamer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Date;
import java.util.Random;
import server.Server;

public class User implements Runnable {

    private int OFFSET = 10;
    private int SIZE = 100;
    int id;
    int port;
    int age;
    String name;
    Player player;
    PrintStream writer;
    BufferedReader reader;
    Socket sock;

    public User(int id, Socket cSocket) {
        this.sock = cSocket;
        this.id = id;

        try {
            
            this.reader = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            this.writer = new PrintStream(sock.getOutputStream());
            
        } catch (IOException ex) {
        }

        
        // Set Client id
        writer.println(id);
        writer.flush();
        writer.close(); //沒用了

            
        // ****************************************************
        // Get Client info
        //reader.readLine().trim();
        
        //name = "???";
        //port = "???";

        // ****************************************************
            
        /*
        // Start Connection
        Date now = new Date();
        String ip = cSocket.getInetAddress().getHostAddress();
        System.out.println(now.toString() + "\nIP : " + ip + "\nName : " + name + "\nStart to Connect.\n");
        */
        
        Server.playerList.put(id, new Player(id, SIZE * (new Random().nextFloat()) + OFFSET, SIZE * (new Random().nextFloat()) + OFFSET, 0, 1));
    }
    
    
    private void setCorpseRecord(){
        this.age = Server.playerList.get(id).age;
    }
    
    private void deadAction(){
    }
    
    @Override
    public void run() {
        String message;
        try {
            while ((message = this.reader.readLine()) != null) {
                
                //************* 處理資料 ************//
                String ss[] = message.split(" ");
                //************* 處理資料 ************//
                
                switch(ss[0]){
                    case "DEAD" :
                        // send rank
                        setCorpseRecord();
                        deadAction();
                    case "EXIT" : 
                        // quit (disconnect)
                        //Server.playerList.get(id).status = 0;
                        Object x[] = {age,name};
                        Server.recordList.add(x);
                        
                        Server.playerList.remove(id);
                        
                        reader.close();
                        this.sock.close();
                        throw new Exception();
                }

            }
        } catch (Exception ex) {
            System.out.println( "ID: "+ id + " Name: "+name+" Disconnect.");
        }
    }

}
