package Gamer;

public class Player {
    
    int id; 
    float x; 
    float y; 
    int age;
    int status;
    
    
    Player(int id, float x, float y, int age, int status){
        this.id = id;
        this.x = x;
        this.y = y;
        this.age = age;
        this.status = status;
    }
    
    public void sendData(){}
    
    public void DrawWorld(){}
    
}
